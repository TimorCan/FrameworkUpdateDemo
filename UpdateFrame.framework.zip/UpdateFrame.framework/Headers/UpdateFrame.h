//
//  UpdateFrame.h
//  UpdateFrame
//
//  Created by  jsqx-macbook air on 16/2/15.
//  Copyright © 2016年  jsqx-macbook air. All rights reserved.
//

#import <UIKit/UIKit.h>


//! Project version number for UpdateFrame.
FOUNDATION_EXPORT double UpdateFrameVersionNumber;

//! Project version string for UpdateFrame.
FOUNDATION_EXPORT const unsigned char UpdateFrameVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UpdateFrame/PublicHeader.h>


